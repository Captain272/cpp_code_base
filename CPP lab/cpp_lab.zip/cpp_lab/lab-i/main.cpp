#include <iostream>

using namespace std;
int isPalindrome(int n) ;
int isPerfect(int n) ;
int isFibonacci(int n) ;
int bubbleSort(int n , int arr[]);

long long int allFibonacci[50] ;

int main()
{
    allFibonacci[0] = 0 ;
    allFibonacci[1] = 1 ;
    for(int i = 2 ; i < 50; i++ )
    {
        allFibonacci[i] = allFibonacci[i-1] + allFibonacci[i-2] ;
    }
	
	int n = 0 ;
    cout << "Enter the size : " ;
    cin >> n ;
    int allID[n] ;

    for(int i = 0 ; i < n ; i++)
    {
        cin >> allID[i] ;
    }

    int selected[n] ;
    int selectedCount = 0 ;

    for(int i = 0 ; i < n ; i++)
    {
        if(isPalindrome(allID[i]) || isPerfect(allID[i]) || isFibonacci(allID[i]))
        {
            selected[selectedCount] = allID[i] ;
            selectedCount++ ;
        }
    }
	
	cout << "The selected ids are : " << endl;
    for(int i = 0 ; i < selectedCount ; i++)
    {
        cout << selected[i] << "\t" ;
    }
    cout << endl;

    bubbleSort(selectedCount , selected) ;

    cout << "The selected ids in ascending order is  : " << endl;
    for(int i = 0 ; i < selectedCount ; i++ )
    {
        cout << selected[i]  << "\t " ;
    }
    cout << endl;
    return 0;
}

int isPalindrome(int n)
{
    int rev_n = 0 ;

    int nc = n ;
    while(nc)
    {
        rev_n = (rev_n*10) + nc%10 ;
        nc /= 10 ;
    }

    return rev_n == n ;
}

int isPerfect(int n)
{
    int factSum = 0 ;
    for(int i =1 ; i < n ; i++)
    {
        if(n%i == 0)
        {
            factSum += i ;
        }
    }

    return factSum == n ;

}



int isFibonacci(int n)
{
    int found = 0 ;
    for(int i = 0 ; i < 25 ; i++ )
    {
        if(allFibonacci[i] == n)
        {
            found = 1 ;
            break;
        }
        if(allFibonacci[i] > n )
        {
            break;
        }
    }

    return found==1 ;

}
int bubbleSort(int n , int arr[])
{
    for(int i = 0 ; i < n ; i++ )
    {
        for(int j = 0 ; j < n-i-1 ; j++ )
        {
            if(arr[j] > arr[j+1])
            {
                int temp = arr[j] ;
                arr[j] = arr[j+1] ;
                arr[j+1] = temp ;
            }
        }
    }
}

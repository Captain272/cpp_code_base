#include <iostream>
using namespace std ; 

struct process
{
	int id ; 
	int arrivalTime ; 
	int burstTime ; 
	int startingTime ; 
	int endingTime ; 
	int completionTime ; 
} ; 

int currentTime = 0 ; 


void displayProcess(process p) ; 
int main()
{
	int n ; 
	cout << "Enter the number of process : " ; 
	cin >> n; 
	
	process Processes[n] ; 
	cout << "Enter the detials of the processes : " << endl; 
	for(int i = 0 ; i < n ; i++)
	{
		cout << "Enter ID: " ; 
		cin >> Processes[i].id ; 
		cout << "Enter Arrival time : " ; 
		cin >> Processes[i].arrivalTime ; 
		cout << "Enter Burst time   : " ; 
		cin >> Processes[i].burstTime ; 
	}
	
	for(int i = 0 ; i < n ; i++)
	{
		for(int j = 0 ; j < n-1 ; j++)
		{
			if(Processes[j].arrivalTime > Processes[j+1].arrivalTime)
			{
				process temp = Processes[j] ; 
				Processes[j] = Processes[j+1]  ; 
				Processes[j+1] = temp ; 
			}
			else if(Processes[j].arrivalTime == Processes[j+1].arrivalTime)
			{
				if(Processes[j].id > Processes[j+1].id)
				{
					process temp = Processes[j] ; 
					Processes[j] = Processes[j+1]  ; 
					Processes[j+1] = temp ; 
				}
			}
		}
	}
	
	
	for(int i = 0 ; i < n ; i++)
	{
		Processes[i].startingTime = currentTime ; 
		Processes[i].endingTime   = currentTime + Processes[i].burstTime  ; 
		Processes[i].completionTime = Processes[i].endingTime  - Processes[i].arrivalTime ; 
		currentTime = Processes[i].endingTime ; 
	}
	
	for(int i = 0 ; i < n ; i++)
	{
		for(int j = 0 ; j < n-i-1 ; j++)
		{
			if(Processes[j].id > Processes[j+1].id)
			{
				process temp = Processes[j] ; 
				Processes[j] = Processes[j+1]  ; 
				Processes[j+1] = temp ; 
			}
		}
	}
	
	cout << "The table is : " << endl; 
	//cout << "Process id \t Arrivale Time \t Burst Time \t Starting Time \t Ending time \t Completion Time \n" ; 
	for(int i = 0 ; i < n ; i++)
	{
		displayProcess(Processes[i]) ; 
	}
	
}


void displayProcess(process p)
{
	cout <<"P" << p.id << "\t" << p.arrivalTime << "\t" << p.burstTime << "\t" ;
	cout << p.startingTime << "\t" << p.endingTime << "\t" << p.completionTime << endl; 
}
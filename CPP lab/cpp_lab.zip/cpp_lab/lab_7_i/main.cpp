#include <iostream>
using namespace std; 

class customer
{
private:
	string name ; 
	int accountNumber ; 
	long long int amount ; 
	string address; 
public:
	customer(string n , int acnumber , int money , string add)
	{
		name = n ; 
		accountNumber = acnumber ; 
		amount = money ; 
		address = add ; 
	}
	customer()
	{
		name="" ; 
		accountNumber=-1; 
		amount = 0 ; 
		address="" ; 
	}
	
	customer operator+(customer c);
	customer operator+(int a);
	customer operator-(int a) ; 
	int getAccountNumber(); 
	void getDetails() ; 
	void getDetails(string name , string address) ; 
	void showDetails(); 
	int  getAmount(); 
	void depositAmount(int money) ; 
	void withDrawlAmount(int money) ; 
};

customer customer:: operator+(customer c)
{
	this->amount += c.amount ; 
	return *this ; 
}

customer customer:: operator-(int amount)
{
	this->amount -= amount ; 
	return *this ; 
}

customer customer:: operator+(int amount)
{
	this->amount += amount ; 
	return *this ; 
}

int customer::getAccountNumber()
{
	return accountNumber ; 
}

void customer::getDetails()
{
	cout << "Enter name : " ; 
	cin >> name ; 
	cout << "Enter account number : " ; 
	cin >> accountNumber ; 
	cout << "Enter amount : " ; 
	cin >> amount ; 
	cout << "Enter addresss : " ; 
	cin >> address ; 
}

void customer::getDetails(string n , string a)
{
	name = n ; 
	address = a ; 
}

void customer::showDetails()
{
	cout << "Name : " << name << endl; 
	cout << "Money : " << amount << endl; 
	cout << "Account Number : " << accountNumber << endl ;
	cout << "Address : " << address << endl; 
}

int customer::getAmount()
{
	return amount ; 
}

void customer::depositAmount(int money)
{
	amount += money ; 
}

void customer::withDrawlAmount(int money)
{
	if(money >= 5000 )
	{
		amount -= money ; 
	}
	else 
	{
		cout << "There is not enough minimum available balance " << endl; 
	}
	
}

class BankAccount
{
private:
	int numberOfCustomers ; 
	customer *customers ; 
	static int bankBalance ; 
public:
	BankAccount(int size);
	BankAccount() {} ; 
	
	
	void DisplayCustomer(int accNumber );
	void Depost(int accNumber); 
	void WithDrawl(int accNumber) ; 
	void BalanceEnquiry(int accNumber) ; 
	static void financialStatusOfBank() ; 
	void upDateProfile(int accNumber) ; 
	~BankAccount();
};
BankAccount::BankAccount(int size)
{
	numberOfCustomers = size ; 
	customers = new customer[numberOfCustomers] ; 

	for(int i = 0 ; i < numberOfCustomers ; i++ )
	{
		customers[i].getDetails(); 
		bankBalance += customers[i].getAmount() ; 
	}
}

BankAccount :: ~BankAccount()
{
	delete[] customers ; 
	customers = NULL ; 
}

int BankAccount::bankBalance = 10000; 

void BankAccount::DisplayCustomer(int accNumber)
{

	for(int i = 0 ; i < numberOfCustomers ; i++ )
	{
		if(customers[i].getAccountNumber() == accNumber )
		{
			customers[i].showDetails() ; 
			return ; 
		}
	}
	
	cout << "There is no customer with accountNumber : " << accNumber << endl; 
}

void BankAccount::Depost(int accNumber)
{
	long long int money ; 
	cout << "Enter the amount you want to depost : " ; 
	cin >> money ; 
	for(int i = 0 ; i < numberOfCustomers ; i++ )
	{
		if(customers[i].getAccountNumber() == accNumber)
		{
			customers[i].depositAmount(money) ; 
			bankBalance += money ; 
			return ; 
		}
	}
	
	cout << "There is no customer with account number : " << accNumber << endl; 
}

void BankAccount::WithDrawl(int accNumber)
{
	int money ; 
	cout << "Enter the amount you want to withDrawl : " ; 
	cin >> money ; 
	for(int i= 0; i < numberOfCustomers ; i++ )
	{
		if(customers[i].getAccountNumber() == accNumber) 
		{
			customers[i].withDrawlAmount(money) ; 
			bankBalance -= money ; 
			return ; 
		}
	}
	
	cout << "There is no customer with account number : " << accNumber << endl; 
}

void BankAccount::BalanceEnquiry(int accNumber)
{
	for(int i  = 0 ; i < numberOfCustomers; i++ )
	{
		if(customers[i].getAccountNumber() == accNumber )
		{
			cout << "The amount of accNumber " << accNumber << "is : " << customers[i].getAmount() << endl; 
			return ; 
		}
	}
	cout << "There is no customer with account number : " << accNumber << endl; 
}

void BankAccount::financialStatusOfBank()
{
	cout << "The amount in the bank is : " << bankBalance << endl; 
}

void BankAccount::upDateProfile(int accNumber)
{
	for(int i  = 0 ; i < numberOfCustomers; i++ )
	{
		if(customers[i].getAccountNumber() == accNumber )
		{
			cout << "Enter new name : " ; 
			string newName ; 
			cin >> newName ; 
			cout << "Enter the new address : " ; 
			string newAddress ; 
			cin >> newAddress ; 
			customers[i].getDetails(newName , newAddress) ; 
			return ; 
		}
	}
	cout << "There is no customer with account number : " << accNumber << endl; 
}

int main()
{
	int size ; 
	cout << "Enter the number of customers " << endl; 
	cin >> size ; 
	BankAccount iiit(size) ;
	int option ; 
	int accNumber; 
	while(option != 7)
	{
		cout << "1.Display Customer Profile " << endl; 
		cout << "2.Depost " << endl; 
		cout << "3.With Drawl " << endl; 
		cout << "4.Balance Enquiry " << endl; 
		cout << "5.financial Status " << endl; 
		cout << "6.upDate Profile " << endl; 
		cout << "7.EXIT" << endl; 
		cout << "Enter the option : " << endl; 
		cin >> option ; 
		if(option == 7)
		{
			break; 
		}
		else if(option == 5)
		{
			iiit.financialStatusOfBank(); 
			continue ; 
		}
		cout << "Enter the account Number : " ; 
		cin >> accNumber ; 
		switch (option)
		{
			case 1:
				iiit.DisplayCustomer(accNumber) ; 
				break; 
			case 2:
				iiit.Depost(accNumber) ; 
				break; 
			case 3:
				iiit.WithDrawl(accNumber) ; 
				break; 
			case 4:
				iiit.BalanceEnquiry(accNumber) ; 
				break; 
			 
			case 6:
				iiit.upDateProfile(accNumber) ; 
				break; 
			default:
				cout << "INVALID OPTION" << endl; 
				break; 
			
		}
		cout << endl << endl; 
	}
	return 0 ; 
}
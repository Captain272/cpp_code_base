#include <iostream>
using namespace std ;

struct student
{
    int response[10] ;
    int rollno ;
    string name;
} ;

struct grade
{
    int rollno ;
    string   grade ;
} ;


void displayGrade(grade g) ;
int main()
{
    int key[10] = { 1 , 3  ,5 , 7, 9, 2, 4, 6 ,8 ,10 } ;

    int n ;
    cout << "Enter the number of students : " ;
    cin >> n ;
    student *students = new student[n] ;
    grade   *grades   = new grade[n] ;

    cout << "Enter the student details " << endl;
    for(int i = 0 ; i < n ; i++)
    {
        cout << "student " << i+1 << endl;
        cout << "name : " ;
        cin >> students[i].name ;
        cout << "roll no : ";
        cin >> students[i].rollno ;
        cout << "response : " ;
        for(int r = 0 ; r < 10 ; r++)
        {
            cin >> students[i].response[r] ;
        }
    }
	cout << endl;

    int distinctionCount = 0 , firstCount = 0 , secondCount = 0 , failureCount = 0 ;

    for(int i = 0 ; i < n ; i++)
    {
        int thisStudentMarks = 0 ;
        for(int r = 0 ; r < 10 ; r++ )
        {
            if(students[i].response[r] == key[r])
            {
                thisStudentMarks++ ;
            }
        }
		grades[i].rollno = students[i].rollno ;
        if(thisStudentMarks >= 7)
        {
            grades[i].grade = "Distinction" ;
            distinctionCount++ ;
        }
		
		
        else if(thisStudentMarks == 6)
        {
            grades[i].grade = "First" ;
            firstCount++ ;
        }
        else if(thisStudentMarks == 5)
        {
            grades[i].grade = "Second" ;
            secondCount++ ;
        }
        else
        {
            grades[i].grade = "Failure" ;
            failureCount++ ;
        }
    }	

    grade Distinction[distinctionCount] ;
    grade First[firstCount] ;
    grade Second[secondCount] ;
    grade Failure[failureCount] ;
	
    int DistinctionIndex = 0 , FirstIndex = 0 , SecondIndex = 0 , FailureIndex = 0 ;
    for(int i = 0 ; i < n ;i++)
    {
        if(grades[i].grade == "Distinction")
        {
            Distinction[DistinctionIndex++] = grades[i] ;
        }
        else if(grades[i].grade == "First")
        {
            First[FirstIndex++] = grades[i] ;
        }
        else if(grades[i].grade == "Second")
        {
            Second[SecondIndex++] = grades[i] ;
        }
        else
        {
            Failure[FailureIndex++] = grades[i] ;
        }
    }
	
	cout << "Distinction students are : " << endl;
    for(int i = 0 ; i < DistinctionIndex ; i++)
    {
        displayGrade(Distinction[i]) ;
    }

    cout << endl ;

    cout << "First students are : " << endl ;
    for(int i = 0 ; i < FirstIndex ; i++)
    {
        displayGrade(First[i]) ;
    }

    cout << endl;

    cout << "Second students are : " << endl;
    for(int i = 0 ; i < SecondIndex ; i++)
    {
        displayGrade(Second[i]) ;
    }

    cout << endl;
    cout << "Failure students are : " << endl;
    for(int i = 0 ; i < FailureIndex ; i++)
    {
        displayGrade(Failure[i]) ;
    }


    delete[] students ;
    delete[] grades ;

    cout << endl;
    return 0 ;
}

void displayGrade(grade g)
{
    cout << endl;
    cout << "rollno : " << g.rollno << endl ;
    cout << "grade  : " << g.grade  << endl ;
    cout << endl ;
}

/*
 In a company, there are n number of employees are working. The record of employee contains name, 
 salary, experience, annual performance (Excellent, Very good, Good, Average or Poor) and address.
 As a part of annual increments, company would like to provide hikes as follows:

 if experience is more than 10 years and performance is Excellent, 50% of basic as increment.

 if experience is more than 10 years and performance is Very good or Good/ if experience is 
 5-10 years and performance is Excellent, 30% of basic as increment.

 if experience is more than 10 years and performance is Average/ 
 if experience is 5-10 years and performance is Very good or good/ 
 if experience is 2-3 years and performance is Excellent, 10% of basic as increment.

 Remaining all cases no increment.
 Implement the following in C++:
 1. Read 'n' no. of employees' records and print them.
 2. After increments, find the highest and lowest salary paid employees whose performance is Excellent. If there is a tie in salaries, break it based alphabetical order of their names.
 3. Delete the highest and second highest paid employees' records whose performance is Poor.
*/

#include <iostream>
using namespace std;  

struct employee
{
	string name ;
	double salary ; 
	int experience ;
	char annualPerformance; 
	string address; 
	
};


void displayEmployee(employee e)
{
	cout << endl; 
	cout << "Name : " << e.name << endl; 
	cout << "Salary : " << e.salary << endl; 
	cout << "Experience : " << e.experience << endl; 
	cout << "Annual Performance : " << e.annualPerformance << endl; 
	cout << "Address : " << e.address << endl; 
	cout << endl; 
}

void annualIncrement(employee *e)
{
	if(e->experience > 10 && e->annualPerformance == 'E' )
	{
		e->salary += e->salary*0.5 ; 
	}
	else if(e->experience > 10 && (e->annualPerformance == 'V' ||e->annualPerformance =='G' ))
	{
		e->salary += e->salary*0.3 ; 
	}
	else if( (e->experience >= 5 && e->experience <= 10) && e->annualPerformance == 'E' )
	{
		e->salary += e->salary*0.3 ; 
	}
	else if ( e->experience > 10 && e->annualPerformance == 'A')
	{
		e->salary += e->salary*0.1 ; 
	}
	else if( (e->experience >= 5 && e->experience <= 10) && (e->annualPerformance == 'V' ||e->annualPerformance =='G' ))
	{
		e->salary += e->salary * 0.1 ; 
	}
	else if( (e->experience >= 2 && e->experience <= 3) && e->experience == 'E')
	{
		e->salary += e->salary*0.1 ; 
	}
}

employee *findHighestPaidEmployee(employee employees[] , int size)
{
	employee *highest = &employees[0] ; 
	for(int i = 0 ; i < size ; i++ )
	{
		if(employees[i].salary > highest->salary)
		{
			highest = &(employees[i]) ; 
		}
		else if(employees[i].salary == highest->salary)
		{
			if(highest->name < employees[i].name)
			{
				highest = &(employees[i]) ; 
			}
			else 
			{
				highest = highest ; 
			}
		}
	}
	
	return highest ; 
}

employee *findLowestPaidEmployee(employee employees[] , int size)
{
	employee *lowest = &employees[0] ; 
	for(int i = 0 ; i < size ; i++ )
	{
		if(employees[i].salary < lowest->salary)
		{
			lowest = &(employees[i]) ; 
		}
		else if(employees[i].salary == lowest->salary)
		{
			if(lowest->name < employees[i].name)
			{
				lowest = &(employees[i]) ; 
			}
			else 
			{
				lowest = lowest ; 
			}
		}
	}
	
	return lowest ; 
}


void deletePoorEmployees(employee employees[] , int *size)
{
	employee *highestPaidPoorEmployee = NULL  ; 
	employee *secondHigeshtPaidPoorEmployee = NULL ; 
	
	int highestPaidPoorEmployeeIndex = 0 ; 
	int secondHigeshtPaidPoorEmployeeIndex = 0 ; 
	
	for(int i = 0 ; i < *size ; i++)
	{
		if(employees[i].annualPerformance == 'P')
		{
			highestPaidPoorEmployee = &(employees[i]);
		}
	}
	
	for(int i = 0 ; i < *size ; i++)
	{
		if(employees[i].annualPerformance == 'P' && 
		employees[i].salary > highestPaidPoorEmployee->salary )
		{
			highestPaidPoorEmployee = &(employees[i]) ; 
			highestPaidPoorEmployeeIndex  = i ; 
		}
	}
	
	
	if(highestPaidPoorEmployee != NULL)
	{
		if(highestPaidPoorEmployee->annualPerformance == 'P')
		{
			cout << "going to delete : " << endl; 
			displayEmployee(*highestPaidPoorEmployee) ; 
			for(int i = highestPaidPoorEmployeeIndex; i < *size-1 ; i++)
			{
				employees[i] = employees[i+1]; 
			}
			*size = *size - 1 ; 
			cout << "now the size is : " << *size << endl; 
			
		}
		
	}
	
	for(int i = 0 ; i < *size ; i++)
	{
		if(employees[i].annualPerformance == 'P')
		{
			secondHigeshtPaidPoorEmployee = &(employees[i]) ; 
		}
	}
	
	for(int i = 0 ; i < *size ; i++)
	{
		if(employees[i].annualPerformance == 'P' && 
		employees[i].salary > secondHigeshtPaidPoorEmployee->salary )
		{
			secondHigeshtPaidPoorEmployee = &(employees[i]) ; 
			secondHigeshtPaidPoorEmployeeIndex  = i ; 
		}
	}
	
	if(secondHigeshtPaidPoorEmployee != NULL)
	{		
		if(secondHigeshtPaidPoorEmployee->annualPerformance == 'P')
		{
			
			cout << "going to delete : " << endl; 
			displayEmployee(*secondHigeshtPaidPoorEmployee); 
			for(int i = secondHigeshtPaidPoorEmployeeIndex ; i < *size ; i++)
			{
				employees[i] = employees[i+1] ; 
			}
			*size = *size-1; 
			cout << "now the size is : " << *size << endl; 
		
		}
	}
	
}
int main()
{

	int n ; 
	cout << "Enter the number of employees : " ; 
	cin >> n ; 
	
	employee *employees  = new employee[n] ; 
	cout << "Enter the employees data " << endl; 
	
	//string temp ; 
	for(int i = 0 ; i < n ; i++)
	{
		cout << "Enter the data of employee " << i+1 << endl; 
		cout << "name : " ;
		cin >> employees[i].name ; 
		cout << "salary : " ; 
		cin >> employees[i].salary ; 
		cout << "experience(years) : " ; 
		cin >> employees[i].experience ; 
		cout << "annual performance : " ; 
		cin >> employees[i].annualPerformance ; 
		cout << "address : " ; 
		cin >> employees[i].address ; 
	}
	
	cout << endl << endl; 
	cout << "The employees data is : " << endl; 
	for(int i = 0 ; i < n ; i++)
	{
		displayEmployee(employees[i]) ; 
	}
	
	cout << "Incrementing thier salaries : " << endl; 
	for(int i = 0 ; i < n ; i++)
	{
		annualIncrement(&(employees[i])) ; 
	}
	
	cout << "The employees data is : " << endl; 
	for(int i = 0 ; i < n ; i++)
	{
		displayEmployee(employees[i]) ; 
	}
	
	
	employee *highestPaidEmployeeE = findHighestPaidEmployee(employees , n) ;  
	employee *lowestPaidEmployeeE = findLowestPaidEmployee(employees , n) ; 
	
	cout << "The lowest Paid Employee : " << endl;  
	displayEmployee(*lowestPaidEmployeeE) ; 
	cout << "The highest Paid Employee : " << endl; 
	displayEmployee(*highestPaidEmployeeE) ; 
	
	cout << "Deleting \
	the highest and second highest paid employees' records whose performance is Poor"  << endl; 
	deletePoorEmployees(employees , &n) ; 
	
	cout << "Finally the employees are : " << endl ;
	for(int i = 0 ; i < n ; i++)
	{
		displayEmployee(employees[i]) ; 
	}
	return 0 ; 
}
/*
The exam cell management software maintains academic 
 * details of students. Assume THE FOLLOWING:
 * There are students of 4 banches such as CSE, ECE, MECH,CIVIL. 
 * Each student record contains name, rollno, MT1Marks, MT2Marks, MT3Marks 
 * and EndSemMarks, percentage, where percentage is,
   percentage =(((sum of best two MT marks of three MTs) + EndSemMarks) / 100) * 100.
   Then, implement the following in C++:
   1. Read all 4 branches students and print them.
   2. Overload the upDate() and displayDetails() functions for
   i. to update the names of specific roll numbers of a particular branch.
   ii. to update the roll numbers of specific students (given names) of a particular branch.
   iii. to update marks of specific roll numbers of a particular branch
   iv. to display the details of students given a particular branch.
   v. to display the details of students given their roll numbers of a particular branch.
*/

#include <iostream>
#include <string>
//class displayDetails;
using namespace std ; 

class student 
{
public:
	string name ; 
	int rollNo ; 
	int MT1Marks , MT2Marks , MT3Marks , EndSemMarks ; 
	float percentage ; 
	void getDetailsOfStudent() ; 
	void calculatePercentage() ; 
	void displayStudentDetails() ; 
};

void student::displayStudentDetails()
{
	cout << endl; 
	cout << "Name : " << name << endl; 
	cout << "Roll No : " << rollNo  << endl; 
	cout << "Percentage : " << percentage << endl; 
}
void student::getDetailsOfStudent()
{
	cout << "Enter the name of the student : " ; 
	cin >> name ; 
	cout << "Enter the roll number : " ; 
	cin >> rollNo ; 
	cout << "Enter MT1Marks , MT2Marks , MT3Marks " ; 
	cin >> MT1Marks >>  MT2Marks >> MT3Marks ; 
	cout << "Enter the EndSemMarks : " ; 
	cin >> EndSemMarks ; 
}

void student::calculatePercentage()
{
	int bestOfThree = MT1Marks + MT2Marks ; 
	if( (MT1Marks + MT3Marks) > bestOfThree )
	{
		bestOfThree = MT1Marks + MT3Marks ; 
	}
	if(MT2Marks + MT3Marks > bestOfThree )
	{
		bestOfThree = MT2Marks + MT3Marks ; 
	}
	
	cout << "best of three is : " << bestOfThree << endl; 
	percentage = ((bestOfThree + EndSemMarks ) / 100.0 )*100.0f ; 
	cout << "percentage : " << percentage << endl; 
}

class ExamCell
{
public:
	void initialize() ; 
	void upDate() ; 
	void upDate(int rollno , string branchName) ; 
	void upDate(string studentName , string branchName) ; 
	void upDate(string branchName , int rollNo) ; 
	void displayDetails() ; 
	void displayDetails(string  branchName); 
	void displayDetails(int rollNo , string branchName) ; 
private:
	int cseStudents ; 
	int eceStudents ; 
	int mechStudents ; 
	int civilStudents ; 
	student *CSE ; 
	student *ECE; 
	student *MECH; 
	student *CIVIL ; 
}; 

void ExamCell::initialize()
{
	cout << "Enter the number of cse students : " ; 
	cin >> cseStudents; 
	CSE = new student[cseStudents] ; 
	for(int i = 0 ; i < cseStudents ; i++)
	{
		CSE[i].getDetailsOfStudent();
		CSE[i].calculatePercentage() ; 
	}
	
	cout << "Enter the number of ece students : " ; 
	cin >> eceStudents ; 
	ECE = new student[eceStudents] ;
	for(int i = 0 ; i < eceStudents ; i++)
	{
		ECE[i].getDetailsOfStudent() ; 
		ECE[i].calculatePercentage() ; 
	}
	
	cout << "Enter the number of mech students : " ; 
	cin >> mechStudents ; 
	MECH = new student[mechStudents] ; 
	for(int i = 0 ; i < mechStudents ; i++)
	{
		MECH[i].getDetailsOfStudent() ; 
		MECH[i].calculatePercentage() ; 
	}
	
	cout << "Enter the number of civil students : " ; 
	cin >> civilStudents ; 
	CIVIL = new student[civilStudents] ; 
	for(int i = 0 ; i < civilStudents ; i++)
	{
		CIVIL[i].getDetailsOfStudent() ; 
		CIVIL[i].calculatePercentage() ; 
	}
}

void ExamCell :: displayDetails()
{
	cout << "CSE STUDENTS : " << endl; 
	for(int i = 0 ; i < cseStudents ; i++)
	{
		CSE[i].displayStudentDetails() ; 
	}
	
	cout << "ECE STUDENTS : " << endl ; 
	for(int i = 0  ; i < eceStudents ; i++)
	{
		ECE[i].displayStudentDetails() ; 
	}
	
	cout << "MECH STUDENTS : " << endl; 
	for(int i = 0 ; i < mechStudents ; i++ )
	{
		MECH[i].displayStudentDetails() ; 
	}
	
	cout << "CIVIL STUDENTS : " << endl; 
	for(int i= 0 ; i < civilStudents ; i++)
	{
		CIVIL[i].displayStudentDetails() ; 
	}
}

void ExamCell::upDate()
{
	int rollNo ; 
	string branch ;
	string name ; 
	cout << "Enter the branch name : " ; 
	cin >> branch ; 
	cout << "Enter the rollNo : " ; 
	cin >> rollNo ; 
	cout << "Enter the name : " ; 
	cin >> name ; 
	if(branch == "CSE")
	{
		for(int i = 0 ; i < cseStudents ; i++)
		{
			if(CSE[i].rollNo == rollNo)
			{
				cout << "Enter the new name : " ; 
				cin >> CSE[i].name ; 
				cout << "Enter the new roll no : " ; 
				cin >> CSE[i].rollNo ; 
				
			}
		}
	}
	else if(branch == "ECE")
	{
		for(int i = 0 ; i < eceStudents ; i++)
		{
			if(ECE[i].rollNo == rollNo)
			{
				cout << "Enter the new name : " ; 
				cin >> ECE[i].name ; 
				cout << "Enter the new roll no : " ; 
				cin >> ECE[i].rollNo ; 
				
			}
		}
	}
	else if(branch == "MECH")
	{
		for(int i = 0 ; i < mechStudents ; i++)
		{
			if(MECH[i].rollNo == rollNo)
			{
				cout << "Enter the new name : " ; 
				cin >> MECH[i].name ; 
				cout << "Enter the new roll no : " ; 
				cin >> MECH[i].rollNo ; 
			}
		}
	}
	else if(branch == "CIVIL")
	{
		for(int i = 0 ; i < civilStudents ; i++)
		{
			if(CIVIL[i].rollNo == rollNo)
			{
				cout << "Enter the new name : " ; 
				cin >> CIVIL[i].name ; 
				cout << "Enter the new roll no : " ; 
				cin >> CIVIL[i].rollNo ; 	
			}
		}
	}
}

void ExamCell::upDate(int rollNo , string branchName)
{
	cout << "changing the student name with rollno : " << rollNo << " of branch : " << branchName << endl; 
	if(branchName == "CSE")
	{
		for(int i = 0 ; i < cseStudents ; i++)
		{
			if(CSE[i].rollNo == rollNo)
			{
				cout << "Enter the new name : " ; 
				cin >> CSE[i].name ; 
			}
		}
	}
	else if(branchName == "ECE")
	{
		for(int i = 0 ; i < eceStudents ; i++)
		{
			if(ECE[i].rollNo == rollNo)
			{
				cout << "Enter the new name : " ; 
				cin >> ECE[i].name ; 
			}
		}
	}
	else if(branchName == "MECH")
	{
		for(int i = 0 ; i < mechStudents ; i++)
		{
			if(MECH[i].rollNo == rollNo)
			{
				cout << "Enter the new name : " ; 
				cin >> MECH[i].name ; 				
			}
		}
	}
	else if(branchName == "CIVIL")
	{
		for(int i = 0 ; i < civilStudents ; i++)
		{
			if(CIVIL[i].rollNo == rollNo)
			{
				cout << "Enter the new name : " ; 
				cin >> CIVIL[i].name ; 				
			}
		}
	}
}

void ExamCell::upDate(string name , string branchName)
{
	cout << "changing the rollNo of student with name : " << name << " of branch : " << branchName << endl; 
	if(branchName == "CSE")
	{
		for(int i = 0 ; i < cseStudents ; i++)
		{
			if(CSE[i].name == name)
			{
				cout << "Enter the new roll no : " ; 
				cin >> CSE[i].rollNo ; 
			}
		}
	}
	else if(branchName == "ECE")
	{
		for(int i = 0 ; i < eceStudents ; i++)
		{
			if(ECE[i].name == name)
			{
				cout << "Enter the new roll no : " ; 
				cin >> ECE[i].rollNo ; 
			}
		}
	}
	else if(branchName == "MECH")
	{
		for(int i = 0 ; i < mechStudents ; i++)
		{
			if(MECH[i].name == name)
			{
				if(CSE[i].name == name)
			{
				cout << "Enter the new roll no : " ; 
				cin >> MECH[i].rollNo ; 
			}				
			}
		}
	}
	else if(branchName == "CIVIL")
	{
		for(int i = 0 ; i < civilStudents ; i++)
		{
			if(CIVIL[i].name == name)
			{
				cout << "Enter the new roll no : " ; 
				cin >> CIVIL[i].rollNo ; 
			}
		}
	}
}

void ExamCell::upDate(string branchName , int rollNo)
{
	cout << "Updating the marks of student with rollNo : " << rollNo << " of branch : " << branchName << endl; 
	if(branchName == "CSE")
	{
		for(int i = 0 ; i < cseStudents ; i++)
		{
			if(CSE[i].rollNo == rollNo)
			{
				cout << "Enter the new marks for this student :" << endl; 
				cout << "Enter MT1 , MT2 , MT3 MARKS : " ; 
				cin >> CSE[i].MT1Marks >> CSE[i].MT2Marks >> CSE[i].MT3Marks ; 
				cout << "Enter the EndSemMarks : " ; 
				cin >> CSE[i].EndSemMarks ; 
				CSE[i].calculatePercentage() ; 
			}
		}
	}
	else if(branchName == "ECE")
	{
		for(int i = 0 ; i < eceStudents ; i++)
		{
			if(ECE[i].rollNo == rollNo)
			{
				cout << "Enter the new marks for this student :" << endl; 
				cout << "Enter MT1 , MT2 , MT3 MARKS : " ; 
				cin >> ECE[i].MT1Marks >> ECE[i].MT2Marks >> ECE[i].MT3Marks ; 
				cout << "Enter the EndSemMarks : " ; 
				cin >> ECE[i].EndSemMarks ; 
				ECE[i].calculatePercentage() ; 
			}
		}
	}
	else if(branchName == "MECH")
	{
		for(int i = 0 ; i < mechStudents ; i++)
		{
			
			if(MECH[i].rollNo == rollNo)
			{
				cout << "Enter the new marks for this student :" << endl; 
				cout << "Enter MT1 , MT2 , MT3 MARKS : " ; 
				cin >> MECH[i].MT1Marks >> MECH[i].MT2Marks >> MECH[i].MT3Marks ; 
				cout << "Enter the EndSemMarks : " ; 
				cin >> MECH[i].EndSemMarks ; 
			}
		}
	}
	else if(branchName == "CIVIL")
	{
		for(int i = 0 ; i < civilStudents ; i++)
		{
			
			if(CIVIL[i].rollNo == rollNo)
			{
				cout << "Enter the new marks for this student :" << endl; 
				cout << "Enter MT1 , MT2 , MT3 MARKS : " ; 
				cin >> CIVIL[i].MT1Marks >> CIVIL[i].MT2Marks >> CIVIL[i].MT3Marks ; 
				cout << "Enter the EndSemMarks : " ; 
				cin >> CIVIL[i].EndSemMarks ; 
			}
		}
	}
}

void ExamCell::displayDetails(string branchName)
{
	cout << "displaying the student names with the branch : " << branchName << endl; 
	if(branchName == "CSE")
	{
		cout << "CSE STUDENTS : " << endl; 
		for(int i = 0 ; i < cseStudents ; i++)
		{
			CSE[i].displayStudentDetails() ; 
		}
	}
	else if(branchName == "ECE")
	{
		cout << "ECE STUDENTS : " << endl ; 
		for(int i = 0  ; i < eceStudents ; i++)
		{
			ECE[i].displayStudentDetails() ; 
		}
	}
	else if(branchName == "MECH")
	{
		cout << "MECH STUDENTS : " << endl; 
		for(int i = 0 ; i < mechStudents ; i++ )
		{
			MECH[i].displayStudentDetails() ; 
		}
	}
	else if(branchName == "CIVIL")
	{
		cout << "CIVIL STUDENTS : " << endl; 
		for(int i= 0 ; i < civilStudents ; i++)
		{
			CIVIL[i].displayStudentDetails() ; 
		}
	}
}

void ExamCell::displayDetails(int rollNo , string branchName)
{
	cout << "displaying the detials of student with rollNO : " << rollNo << " of branch : " << branchName << endl; 
	if(branchName == "CSE")
	{
		for(int i = 0 ; i < cseStudents ; i++)
		{
			if(CSE[i].rollNo == rollNo)
			{
				CSE[i].displayStudentDetails() ; 
			}
		}
	}
	else if(branchName == "ECE")
	{
		for(int i = 0  ; i < eceStudents ; i++)
		{
			if(ECE[i].rollNo == rollNo)
			{
				ECE[i].displayStudentDetails() ; 
			}
		}
	}
	else if(branchName == "MECH")
	{
		for(int i = 0 ; i < mechStudents ; i++ )
		{
			if(MECH[i].rollNo == rollNo)
			{
				MECH[i].displayStudentDetails() ; 
			}
		}
	}
	else if(branchName == "CIVIL")
	{
		for(int i= 0 ; i < civilStudents ; i++)
		{
			if(CIVIL[i].rollNo == rollNo)
			{
				CIVIL[i].displayStudentDetails() ; 
			}
		}
	}
}


int main()
{
	/*
	 *void upDate(int rollno , string branchName) ; 
	void upDate(string studentName , string branchName) ; 
	void upDate(string branchName , int rollNo) ; 
	void displayDetails() ; 
	void displayDetails(string  branchName); 
	void displayDetails(int rollNo , string branchName) ;  
	 * 
	*/
	ExamCell ec ; 
	ec.initialize() ; 
	ec.displayDetails() ; 
	ec.upDate(28 , "CSE") ; 
	ec.upDate("babu" , "CSE") ; 
	ec.upDate("CSE" , 28) ; 
	ec.displayDetails("CSE");
	ec.displayDetails(28, "CSE"); 
	return 0 ; 
}

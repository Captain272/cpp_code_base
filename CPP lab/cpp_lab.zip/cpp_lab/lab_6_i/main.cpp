/*
 *In an Institute, assume that there are n number of teaching faculty, 
 * m number of non-teaching faculty, p number of housekeeping,
 * q number of security and s number of students. Also, assume the following:
	Institute' available funds is Rs.100 Cr.
	Paying salary for each teaching faculty is Rs.60000 pm
	Paying salary for non-teaching faculty is Rs.20000 pm
	Paying salary for each security is Rs.10000 pm
	Paying salary for each housekeeping is Rs.10000 pm
	Campus monthly maintenance is Rs.5000000
	Annually institute gets say Rs 40000 as scholarship for each each.
	Implement the following in C++(use class and friend functions):
	1. Calculate and print total expenses of the institute.
	2.Calculate and print total expenses for teaching faculty.
	3. Calculate and print total expenses for non-teaching.
	4. Calculate and print total expenses for security.
	5.Calculate and print total expenses for housekeeping.
	6. Calculate and print total scholarship receivedby the institute.
*/





#include <iostream>
using namespace std ; 

class InstituteFunds
{
private:
	int teachingFaculty ; 
	int nonTeachingFaculty;
	int houseKeeping ; 
	int security;
	int students;
	
	long long int initialFunds = 1000000000 ;
	int teachingFacultySalary = 60000 ; 
	int nonTeachingFacultySalary = 20000; 
	int houseKeepingSalary = 10000 ; 
	int securitySalary = 10000; 
	int campusMonthlyMaintainance = 5000000; 
	int scholarShipAmountForEachStudent = 40000 ; 
public:
	void initialize() ; 
	friend void AddScholarshipAmount(InstituteFunds &IF) ; 
	friend long long int CalculateForTeachingFaculty(InstituteFunds &IF); 
	friend long long int CalculateForNonTeachingFaculty(InstituteFunds &IF); 
	friend long long int CalculateForSecurity(InstituteFunds & IF) ; 
	friend long long int  CalculateForHouseKeeping(InstituteFunds &IF);
	friend long long int  CalculateScholarshipAmount(InstituteFunds & IF); 
	friend long long int CalculateCampusMaintanance(InstituteFunds &IF) ; 
	friend void CalculateTotalExpenses(InstituteFunds &IF); 
	long long int getAmount()
	{
		return initialFunds ; 
	}
};


long long int CalculateForTeachingFaculty(InstituteFunds &IF)
{
	long long int expensesForTeachingFaculty = IF.teachingFaculty * IF.teachingFacultySalary; 
	expensesForTeachingFaculty *= 12 ; 
	cout << "The amount for " << IF.teachingFaculty << " teaching faculty is : " << expensesForTeachingFaculty << endl; 
	return expensesForTeachingFaculty ; 
}

long long int CalculateForNonTeachingFaculty(InstituteFunds &IF)
{
	long long int expensesForNonTeachingFaculty = IF.nonTeachingFaculty * IF.nonTeachingFacultySalary; 
	expensesForNonTeachingFaculty *= 12 ; 
	cout << "The amount for " << IF.nonTeachingFaculty << " teaching faculty is : " << expensesForNonTeachingFaculty << endl; 
	return expensesForNonTeachingFaculty ; 
}

long long int CalculateForSecurity(InstituteFunds & IF)
{
	long long int expensesForSecurity = IF.security * IF.securitySalary; 
	expensesForSecurity *= 12 ; 
	cout << "The amount for " << IF.security << " security membersis : " << expensesForSecurity << endl ; 
	return expensesForSecurity ; 
}

long long int  CalculateForHouseKeeping(InstituteFunds &IF)
{
	long long int expensesForHouseKeeping = IF.houseKeeping * IF.houseKeepingSalary ; 
	expensesForHouseKeeping *= 12 ; 
	cout << "The amount for " << IF.houseKeeping << " house keeping members is : " << expensesForHouseKeeping << endl; 
	return expensesForHouseKeeping ; 
}

long long int  CalculateScholarshipAmount(InstituteFunds & IF)
{
	long long int scholarshipAmount = IF.students * IF.scholarShipAmountForEachStudent ; 
	cout << "The total scholarShip amount is : " << scholarshipAmount << endl; 
	IF.initialFunds += scholarshipAmount ; 
	return scholarshipAmount ; 
}

long long int CalculateCampusMaintanance(InstituteFunds &IF)
{
	long long int campusMaintanance = IF.campusMonthlyMaintainance * 12 ; 
	cout << "The campus annual maintanance is : " << campusMaintanance << endl; 
	return campusMaintanance ; 
}

void CalculateTotalExpenses(InstituteFunds &IF)
{
	long long int totalExpenses = CalculateForHouseKeeping(IF) + CalculateForTeachingFaculty(IF) + CalculateForNonTeachingFaculty(IF) +	CalculateForSecurity(IF) + CalculateCampusMaintanance(IF) ;  
	cout << "The total Yearly Expeses are : " << totalExpenses << endl; 
	IF.initialFunds -= totalExpenses ; 
}

void InstituteFunds::initialize()
{
	cout << "Enter the number of teaching Faculty : " ; 
	cin >> teachingFaculty ; 
	cout << "Enter the number of non teaching faculty : " ; 
	cin >> nonTeachingFaculty ; 
	cout << "Enter the number of houseKeeping members : " ; 
	cin >> houseKeeping ; 
	cout << "Enter the number of security members : " ; 
	cin >> security ; 
	cout << "Enter the number of students : " ; 
	cin >> students ; 
}

int main()
{
	InstituteFunds iif ; 
	iif.initialize() ; 
	CalculateTotalExpenses(iif) ; 
	CalculateScholarshipAmount(iif) ; 
	cout << "The final amount is : " << iif.getAmount() << endl; 
	return 0 ; 
}